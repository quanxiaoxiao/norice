const path = require('path');

module.exports = pathname => path.resolve(process.cwd(), pathname);
